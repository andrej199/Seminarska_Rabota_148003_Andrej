package com.example.Seminarska_rabota_148003;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SeminarskaRabota148003ApplicationTests {

	@Test
	void contextLoads() {
	}

}
