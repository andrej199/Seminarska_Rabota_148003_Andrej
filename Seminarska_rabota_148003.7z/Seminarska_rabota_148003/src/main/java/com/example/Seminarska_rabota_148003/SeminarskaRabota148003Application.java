package com.example.Seminarska_rabota_148003;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SeminarskaRabota148003Application {

	public static void main(String[] args) {
		SpringApplication.run(SeminarskaRabota148003Application.class, args);
	}

}
