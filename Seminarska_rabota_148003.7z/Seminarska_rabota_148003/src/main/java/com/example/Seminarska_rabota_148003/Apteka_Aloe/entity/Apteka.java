package com.example.Seminarska_rabota_148003.Apteka_Aloe.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.NotBlank;

@Entity
public class Apteka {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long id;

    @NotBlank(message = "Ime se")
    @Column(name = "Ime")
    private String ime;

    @NotBlank(message = "Email se")
    @Column(name = "email")
    private String email;

    @Column(name = "telefon")
    private long telefon;

    @NotBlank(message = "Address se")
    @Column(name = "address")
    private String address;

    public Apteka() {}

    public Apteka(String name, String email) {
        this.ime = name;
        this.email = email;
        this.address = address;
    }

    public void setId(long id) {
        this.id = id;
    }

    public long getId() {
        return id;
    }

    public void setName(String name) {
        this.ime = name;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setAddress(String address) { this.address = address; }

    public String getName() {
        return ime;
    }

    public String getEmail() {
        return email;
    }

    public String getAddress() {return address;}

    public long getPhoneNo() {
        return telefon;
    }

    public void setPhoneNo(long phoneNo) {
        this.telefon = phoneNo;
    }
}
