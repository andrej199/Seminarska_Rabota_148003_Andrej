package com.example.Seminarska_rabota_148003.Apteka_Aloe.repository;

import com.example.Seminarska_rabota_148003.Apteka_Aloe.entity.Apteka;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class AptekaRepository extends CrudRepository<Apteka, Long> {
    List<Apteka> findByName(String name);
}

