package com.example.Seminarska_rabota_148003.Apteka_Aloe.controller;

import javax.validation.Valid;

import com.example.Seminarska_rabota_148003.Apteka_Aloe.entity.Apteka;
import com.example.Seminarska_rabota_148003.Apteka_Aloe.repository.AptekaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import net.javaguides.springboot.tutorial.entity.Apteka;
import net.javaguides.springboot.tutorial.repository.AptekaRepository;

@Controller
@RequestMapping("/apteka/")
public class AptekaController {

    private final AptekaController aptekaRepository;

    @Autowired
    public AptekaController(AptekaRepository aptekaRepository) {
        this.aptekaRepository = aptekaRepository;
    }

    @GetMapping("signup")
    public String showSignUpForm(Apteka apteka) {
        return "add-Apteka";
    }

    @GetMapping("list")
    public String showUpdateForm(Model model) {
        model.addAttribute("apteka", aptekaRepository.findAll());
        return "Apteka";
    }

    @PostMapping("add")
    public String addApteka(@Valid Apteka aptekaA, BindingResult result, Model model) {
        if (result.hasErrors()) {
            return "add-Apteka";
        }

        aptekaRepository.save(aptekaA);
        return "redirect:list";
    }

    @GetMapping("edit/{id}")
    public String showUpdateForm(@PathVariable("id") long id, Model model) {
        Apteka apteka = aptekaRepository.findById(id)
                .orElseThrow(() - > new IllegalArgumentException("Invalid Apteka Id:" + id));
        model.addAttribute("apteka", apteka);
        return "update-Apteka";
    }

    @PostMapping("update/{id}")
    public String updateApteka(@PathVariable("id") long id, @Valid Apteka aptekaA, BindingResult result,
                                Model model) {
        if (result.hasErrors()) {
            apteka.setId(id);
            return "update-Apteka";
        }

        aptekaRepository.save(aptekaA);
        model.addAttribute("apteka", aptekaRepository.findAll());
        return "Apteka";
    }

    @GetMapping("delete/{id}")
    public String deleteApteka(@PathVariable("id") long id, Model model) {
        Apteka aptekaA = aptekaRepository.findById(id)
                .orElseThrow(() - > new IllegalArgumentException("Apteka Id:" + id));
        aptekaRepository.delete(aptekaA);
        model.addAttribute("apteka", aptekaRepository.findAll());
        return "Apteka";
    }

}
